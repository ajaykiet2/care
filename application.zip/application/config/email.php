<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| EMAIL CONFING
| -------------------------------------------------------------------
| Configuration of outgoing mail server.
| */
$config['protocol']='smtp';
$config['smtp_host']='ssl://smtp.googlemail.com';
$config['smtp_port']=465;
$config['smtp_timeout']=30;
$config['smtp_user']='ajayratm22@gmail.com';
$config['smtp_pass']='letmein@gmail';
$config['charset']='utf-8';
$config['newline']="\r\n";
