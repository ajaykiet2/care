<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model(["environment","admin"]);
		if(!$this->admin->isLoggedIn()){
			redirect('/', 'refresh');
			return;
		}
	}

	public function index(){
		$this->session->set_userdata("active_manu","admins");
		$this->load->view('admin_listing');
	}

  public function donees(){

		$this->session->set_userdata("active_manu","donees");
    $this->load->view("donee_listing");
  }

  public function donors(){
		// TODO: get the data of donors and fill
		$this->session->set_userdata("active_manu","donors");
    $this->load->view("donor_listing");
  }

	public function users(){
		$this->session->set_userdata("active_manu","users");
    $this->load->view("user_listing");
	}
	
	public function transactions(){
		$this->session->set_userdata("active_manu","transactions");
		$this->load->view("transactions");
	}

	public function companyProfile(){
		$this->load->view("about_us");
	}
}
