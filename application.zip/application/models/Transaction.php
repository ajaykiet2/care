<?php
class Transaction extends CI_Model{

  public function __construct(){
    parent::__construct();
  }

  public function get($txn_number){
    return $this->db->get_where("transaction",["txn_number"=>$txn_number])->row();
  }

  public function createTransaction($transaction){
    return $this->db->insert("transaction",$transaction);
  }

  public function updateTransaction($txn_number, $data){
    $this->db->where("txn_number",$txn_number);
    return $this->db->update("transaction", $data);
  }

}
