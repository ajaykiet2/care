<?php $this->load->view("common/header");
$this->load->view("common/sidebar");
$this->load->view("common/widgets/blank_header");?>
<div class="content">
    How to use
</div>
<?php $this->load->view("common/scripts");
 $this->load->view("common/footer");?>