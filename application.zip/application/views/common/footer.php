    <footer class="footer" >
      <div class="container-fluid">
        <!-- <nav>
          <ul>
            <li>
              <a href="<?=base_url("about-us");?>">
                About Us
              </a>
            </li>
            <li>
              <a href="<?=base_url("terms-of-use");?>">
                Terms Of Use
              </a>
            </li>
          </ul>
        </nav> -->
        <div class="copyright" id="copyright">
          &copy;<?=date("Y");?> All Rights Reserved <a href="#" target="_blank">Care India</a>. Developed by <a href="#" target="_blank">Ajay Kumar</a>.
        </div>
      </div>
    </footer>
  </div>
</div>
</body>
</html>
