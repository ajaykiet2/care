<script src="<?=base_url("assets/js/core/jquery.min.js");?>" ></script>
<script src="<?=base_url("assets/js/core/popper.min.js");?>" ></script>
<script src="<?=base_url("assets/js/core/bootstrap.min.js");?>" ></script>
<script src="<?=base_url("assets/js/plugins/perfect-scrollbar.jquery.min.js");?>" ></script>
<script src="<?=base_url("assets/js/now-ui-dashboard.min69ea.js?v=1.1.2");?>" type="text/javascript"></script>
