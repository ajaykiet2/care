<div class="panel-header panel-header-lg">
  <canvas id="bigDashboardChart"></canvas>
</div>
