<?php
  $this->load->view("common/header");
  $this->load->view("common/sidebar");
  $this->load->view("common/widgets/blank_header");
?>

<div class="contents">
</div>

<?php $this->load->view("common/scripts"); ?>
<?php $this->load->view("common/footer"); ?>
